export enum AppState {
  IDLE,
  PROCESSING,
  SUCCESS,
  ERROR,
}

export interface DetectedFeature {
  name: string;
  description: string;
}

export interface Mission {
  name: string;
  description: string;
}

export interface PlanetAnalysis {
  isPlanet: boolean;
  planetName: string;
  planetInfo: string;
  features: DetectedFeature[];
  missions: Mission[];
}
