import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { PlanetAnalysis } from '../types';

// The API key MUST be obtained from the environment variable `process.env.API_KEY`.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const model = 'gemini-2.5-flash';

const responseSchema = {
    type: Type.OBJECT,
    properties: {
      isPlanet: { 
        type: Type.BOOLEAN,
        description: "True if the image is clearly a planet. False for nebulae, galaxies, stars, or non-astronomical objects."
      },
      planetName: { 
        type: Type.STRING,
        description: "The common name of the planet (e.g., \"Mars\"). If not a planet, identify the object (e.g., \"Orion Nebula\", \"Not an astronomical object\")."
      },
      planetInfo: { 
        type: Type.STRING,
        description: "A detailed, multi-paragraph summary covering the planet's physical characteristics (size, mass, composition), atmosphere, orbital characteristics (day length, year length), and unique properties. Make it informative and engaging for an astronomy enthusiast. If not a planet, provide a detailed description of the identified object."
      },
      features: {
        type: Type.ARRAY,
        description: "An array of features CLEARLY VISIBLE in the image. Do NOT invent features. Empty array if no features are visible or if it's not a planet.",
        items: {
          type: Type.OBJECT,
          properties: {
            name: { 
                type: Type.STRING,
                description: "e.g., \"Great Red Spot\", \"Polar Ice Cap\"."
            },
            description: { 
                type: Type.STRING,
                description: "A detailed scientific description of the visible feature, explaining what it is, its scale, its significance, and any relevant scientific context."
            }
          },
          propertyOrdering: ["name", "description"]
        }
      },
      missions: {
        type: Type.ARRAY,
        description: "An array of key space missions for this planet. Prioritize active and recent ones. Empty array if not a planet.",
        items: {
          type: Type.OBJECT,
          properties: {
            name: { 
                type: Type.STRING,
                description: "e.g., \"Juno\", \"Mars Perseverance Rover\"."
            },
            description: { 
                type: Type.STRING,
                description: "A detailed summary of the mission, including its launch date, primary objectives, key instruments, and significant findings or current status."
            }
          },
          propertyOrdering: ["name", "description"]
        }
      }
    }
  };

export const analyzePlanetImage = async (base64Image: string): Promise<PlanetAnalysis> => {
  const imagePart = {
    inlineData: {
      mimeType: 'image/jpeg',
      data: base64Image,
    },
  };

  const textPart = {
    text: `You are an expert astronomer and planetary scientist. Analyze the provided image.
- Base your analysis strictly on the visual evidence.
- Identify if the object is a planet.
- Provide detailed information about the object, its visible features, and related space missions based on the schema.`,
  };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model,
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        temperature: 0.2,
      }
    });

    const text = response.text;
    if (!text) {
        throw new Error("The AI model returned an empty response.");
    }
    
    // With responseSchema, the output should be valid JSON, so we can parse it directly.
    try {
        const parsedData = JSON.parse(text) as PlanetAnalysis;
        return parsedData;
    } catch (e) {
        console.error("Failed to parse JSON response:", e, "Raw response:", text);
        throw new Error("The AI model returned a response in an unexpected format.");
    }
  } catch (error) {
    console.error("Error analyzing image with Gemini:", error);
    if (error instanceof Error && (error.message.includes("API key not valid") || error.message.includes("API key is invalid"))) {
       throw new Error("Invalid API Key. Please ensure the API_KEY environment variable is configured correctly.");
    }
    throw new Error("Failed to analyze the image. The AI model could not process the request.");
  }
};
