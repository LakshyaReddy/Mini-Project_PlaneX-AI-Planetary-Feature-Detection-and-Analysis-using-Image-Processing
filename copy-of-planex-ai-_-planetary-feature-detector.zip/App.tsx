import React, { useState, useCallback } from 'react';
import { AppState, PlanetAnalysis } from './types';
import { analyzePlanetImage } from './services/geminiService';
import { ImageUploader } from './components/ImageUploader';
import { Spinner } from './components/Spinner';
import { PlanetInfoCard } from './components/PlanetInfoCard';
import { FeatureList } from './components/FeatureList';
import { MissionList } from './components/MissionList';
import { ColonyIcon, GamepadIcon, QuizIcon, RocketIcon } from './components/icons';

// --- Game Components ---

interface GameCardProps {
  name: string;
  description: string;
  url: string;
  icon: React.ReactNode;
  gradient: string;
}

const GameCard = ({ name, description, url, icon, gradient }: GameCardProps) => {
  return (
    <div className={`relative rounded-xl p-px ${gradient} shadow-2xl shadow-black/20 h-full`}>
      <div className="bg-slate-900/80 backdrop-blur-sm rounded-[11px] p-6 flex flex-col h-full text-center">
        <div className="flex justify-center mb-4">
          {icon}
        </div>
        <h3 className="text-xl font-bold text-gray-100 mb-2">{name}</h3>
        <p className="text-gray-400 flex-grow mb-6 text-sm">{description}</p>
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-auto block w-full bg-gray-700/50 hover:bg-gray-600/70 text-cyan-300 font-semibold py-2 px-4 rounded-lg transition-all duration-300"
        >
          Play Now
        </a>
      </div>
    </div>
  );
};

const GameSection = () => {
  const games = [
    {
      name: 'The Final Earth 2',
      description: 'Build a great city in this vertical city-builder in space! Gather resources and research your way to a better future.',
      url: 'https://poki.com/en/g/the-final-earth-2',
      icon: <ColonyIcon />,
      gradient: 'bg-gradient-to-br from-cyan-500/50 to-slate-800'
    },
    {
      name: 'NASA Space Place',
      description: 'Test your knowledge about Earth, space and science with fun quizzes and games directly from NASA.',
      url: 'https://spaceplace.nasa.gov/menu/play/',
      icon: <QuizIcon />,
      gradient: 'bg-gradient-to-br from-yellow-500/50 to-slate-800'
    },
    {
      name: 'Space Major Miner',
      description: 'Drill deep into alien planets to mine for valuable resources and upgrade your gear in this addictive digging game.',
      url: 'https://poki.com/en/g/space-major-miner',
      icon: <RocketIcon />,
      gradient: 'bg-gradient-to-br from-orange-500/50 to-slate-800'
    },
    {
      name: 'Space Thing',
      description: 'A fast-paced arcade shooter. Survive waves of enemies in this minimalist top-down space dogfighting game.',
      url: 'https://poki.com/en/g/space-thing',
      icon: <GamepadIcon />,
      gradient: 'bg-gradient-to-br from-purple-600/50 to-slate-800'
    },
     {
      name: 'Space Hopper',
      description: 'Jump from planet to planet in this challenging one-button timing game. How far can you hop across the galaxy?',
      url: 'https://poki.com/en/g/space-hopper',
      icon: <GamepadIcon />,
      gradient: 'bg-gradient-to-br from-indigo-500/50 to-slate-800'
    },
    {
      name: 'Space Ballz',
      description: 'A classic brick-breaker with a cosmic twist. Aim your shots, break the blocks, and collect power-ups.',
      url: 'https://poki.com/en/g/space-ballz',
      icon: <GamepadIcon />,
      gradient: 'bg-gradient-to-br from-pink-500/50 to-slate-800'
    }
  ];

  return (
    <section className="w-full max-w-6xl mx-auto mt-16 animate-fade-in">
      <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-center mb-10" style={{textShadow: '0 0 10px rgba(255, 255, 255, 0.2)'}}>
        <span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-300 via-orange-300 to-red-400">
          Interstellar Arcade
        </span>
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {games.map((game, index) => (
          <GameCard 
            key={index}
            name={game.name}
            description={game.description}
            url={game.url}
            icon={game.icon}
            gradient={game.gradient}
          />
        ))}
      </div>
    </section>
  );
};

interface ActionButtonProps {
    onClick: () => void;
    children: React.ReactNode;
    className?: string;
}

const ActionButton = ({ onClick, children, className }: ActionButtonProps) => (
    <button
      onClick={onClick}
      className={`font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg text-white ${className}`}
    >
      {children}
    </button>
  );


export const App = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageObjectURL, setImageObjectURL] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<PlanetAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = useCallback((base64: string, file: File) => {
    setImageBase64(base64);
    setImageObjectURL(URL.createObjectURL(file));
    setAppState(AppState.IDLE); // Reset to idle to show process button
  }, []);

  const handleProcessImage = async () => {
    if (!imageBase64) return;
    setAppState(AppState.PROCESSING);
    setError(null);
    setAnalysisResult(null);

    try {
      const result = await analyzePlanetImage(imageBase64);
      setAnalysisResult(result);
      setAppState(AppState.SUCCESS);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      setAppState(AppState.ERROR);
    }
  };

  const handleReset = () => {
    setAppState(AppState.IDLE);
    setImageBase64(null);
    if(imageObjectURL) URL.revokeObjectURL(imageObjectURL);
    setImageObjectURL(null);
    setAnalysisResult(null);
    setError(null);
  };
  
  const renderContent = () => {
    switch (appState) {
      case AppState.PROCESSING:
        return (
            <div className="flex flex-col items-center gap-8">
                {imageObjectURL && (
                    <img src={imageObjectURL} alt="Uploaded planet" className="max-w-sm w-full rounded-lg shadow-2xl shadow-black/50" />
                )}
                <Spinner text="Analyzing celestial body..." />
            </div>
        );
      case AppState.SUCCESS:
        return analysisResult && (
          <div className="w-full max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            <div className="flex flex-col items-center gap-6">
                {imageObjectURL && (
                    <img src={imageObjectURL} alt="Analyzed planet" className="max-w-sm w-full rounded-lg shadow-2xl shadow-black/50" />
                )}
                <ActionButton
                  onClick={handleReset}
                  className="bg-cyan-600 hover:bg-cyan-500 hover:shadow-cyan-400/40"
                >
                  Analyze Another Image
                </ActionButton>
            </div>
            <div className="space-y-8">
              {!analysisResult.isPlanet && (
                <div className="bg-black/40 backdrop-blur-sm border border-yellow-500/50 text-yellow-200 p-4 rounded-lg shadow-lg shadow-yellow-500/10">
                    <p className="font-bold text-yellow-300">Object Not Identified as a Planet</p>
                    <p className="whitespace-pre-wrap">{analysisResult.planetInfo.trim()}</p>
                </div>
              )}
              {analysisResult.isPlanet && (
                <>
                  <PlanetInfoCard name={analysisResult.planetName} info={analysisResult.planetInfo} />
                  {analysisResult.features.length > 0 && <FeatureList features={analysisResult.features} />}
                  {analysisResult.missions.length > 0 && <MissionList missions={analysisResult.missions} />}
                </>
              )}
            </div>
          </div>
        );
      case AppState.ERROR:
        return (
          <div className="text-center bg-black/40 backdrop-blur-sm border border-red-500/60 p-6 rounded-lg max-w-md mx-auto shadow-2xl shadow-red-500/20">
            <h3 className="text-xl font-bold text-red-400 mb-2">Analysis Failed</h3>
            <p className="text-red-300 mb-4">{error}</p>
            <ActionButton
              onClick={handleReset}
              className="bg-red-600 hover:bg-red-500 hover:shadow-red-500/40"
            >
              Try Again
            </ActionButton>
          </div>
        );
      case AppState.IDLE:
      default:
        return (
          <div className="flex flex-col items-center gap-8 w-full">
            {!imageObjectURL ? (
               <ImageUploader onImageUpload={handleImageUpload} />
            ) : (
                <div className="flex flex-col items-center gap-6">
                     <img src={imageObjectURL} alt="Selected planet" className="max-w-sm w-full rounded-lg shadow-2xl shadow-black/50" />
                     <ActionButton
                        onClick={handleProcessImage}
                        className="bg-purple-600 hover:bg-purple-500 hover:shadow-purple-500/40"
                     >
                        Identify & Analyze
                     </ActionButton>
                </div>
            )}
           <GameSection />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen w-full text-white p-4 sm:p-8 flex flex-col items-center relative z-10">
      <header className="text-center mb-12">
        <h1 className="text-5xl sm:text-8xl font-black tracking-wider uppercase" style={{textShadow: '0 0 20px rgba(229, 139, 244, 0.6), 0 0 40px rgba(159, 150, 255, 0.4)'}}>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-500">
                PlaneX AI
            </span>
        </h1>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-2" style={{textShadow: '0 0 15px rgba(100, 200, 255, 0.5), 0 0 30px rgba(100, 200, 255, 0.3)'}}>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 to-purple-400">
            Planetary Feature Detector
          </span>
        </h2>
        <p className="mt-4 text-lg text-gray-400 max-w-2xl mx-auto">
          Upload an image of a planet to identify it and discover its prominent features using AI.
        </p>
      </header>
      <main className="w-full flex-grow flex items-center justify-center">
        {renderContent()}
      </main>
    </div>
  );
};