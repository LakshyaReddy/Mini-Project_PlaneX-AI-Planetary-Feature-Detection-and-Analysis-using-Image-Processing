import React from 'react';

export const UploadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-4-4V7a4 4 0 014-4h10a4 4 0 014 4v5a4 4 0 01-4 4H7z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 16v1a2 2 0 01-2 2H6a2 2 0 01-2-2v-1" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 12l-4-4m4 4l4-4m-4 4v4" />
  </svg>
);

export const PlanetIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h8a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.8 14.945a4.012 4.012 0 00-4.745 0M16.2 14.945a4.012 4.012 0 014.745 0M12 18.5a4.5 4.5 0 100-9 4.5 4.5 0 000 9z" />
    </svg>
);

export const TelescopeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 10l-6 6" />
    </svg>
);

export const SatelliteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8V4.82c0-.98.63-1.87 1.56-2.22.45-.17.95-.17 1.4 0 .93.35 1.56 1.24 1.56 2.22V8" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.18V16" />
        <path strokeLinecap="round" strokeLinejoin="round" d="m15.03 5.03-3.06 3.06" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 12.5h-1.25a2.5 2.5 0 0 0-2.5 2.5V16" />
        <rect width="6" height="6" x="9" y="9" rx="2" strokeLinecap="round" strokeLinejoin="round" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 4h2a2 2 0 0 1 2 2v2" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 20H6a2 2 0 0 1-2-2v-2" />
    </svg>
);

export const GamepadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.532 8.928a.75.75 0 10-1.06-1.06l-2.008 2.007-2.008-2.007a.75.75 0 10-1.06 1.06l2.007 2.008-2.007 2.008a.75.75 0 101.06 1.06l2.008-2.007 2.008 2.007a.75.75 0 101.06-1.06l-2.007-2.008 2.007-2.008z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 15.75H6v-1.5h2.25V12H6V9.75h2.25V7.5H6a2.25 2.25 0 00-2.25 2.25v6A2.25 2.25 0 006 18h2.25v-2.25z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 12a8.25 8.25 0 1016.5 0 8.25 8.25 0 00-16.5 0z" />
    </svg>
);


export const ColonyIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 21h19.5m-18-18v18A2.25 2.25 0 006.75 21h10.5a2.25 2.25 0 002.25-2.25V3m-15 0h15" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 6H8.25v3H5.25zM15.75 6h3v3h-3zM5.25 12H8.25v3H5.25zM15.75 12h3v3h-3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v12m-3-6h6" />
    </svg>
);

export const QuizIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" />
    </svg>
);

export const RocketIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.63 2.25a14.98 14.98 0 00-3.72 2.18m10.36 8.86l-8.77-8.77m8.77 8.77l-1.09 1.09a6 6 0 01-8.49-8.49l.7-.7a6 6 0 016.15-1.57m-3.92 8.88a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.63 2.25a14.98 14.98 0 00-3.72 2.18m10.36 8.86l-8.77-8.77" />
    </svg>
);