import React from 'react';
import { DetectedFeature } from '../types';
import { TelescopeIcon } from './icons';

interface FeatureListProps {
  features: DetectedFeature[];
}

export const FeatureList = ({ features }: FeatureListProps) => {
  return (
    <div className="relative rounded-xl p-px bg-gradient-to-b from-purple-500/40 to-slate-800 shadow-2xl shadow-purple-500/10 transition-all duration-300 hover:shadow-purple-500/20">
      <div className="bg-slate-900/80 backdrop-blur-sm rounded-[11px] p-6">
        <h3 className="text-2xl font-bold text-purple-300 flex items-center mb-4 drop-shadow-[0_0_5px_theme(colors.purple.500)]">
          <TelescopeIcon />
          Detected Features
        </h3>
        <ul className="space-y-4">
          {features.map((feature, index) => (
            <li key={index} className="border-l-4 border-purple-400/60 pl-4 transition-all duration-300 hover:border-purple-300 hover:bg-white/5 rounded-r-md py-1">
              <h4 className="font-semibold text-lg text-gray-100">{feature.name}</h4>
              <p className="text-gray-400 whitespace-pre-wrap">{feature.description.trim()}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
