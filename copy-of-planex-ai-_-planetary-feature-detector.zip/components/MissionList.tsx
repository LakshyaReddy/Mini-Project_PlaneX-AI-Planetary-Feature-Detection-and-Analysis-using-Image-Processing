import React from 'react';
import { Mission } from '../types';
import { SatelliteIcon } from './icons';

interface MissionListProps {
  missions: Mission[];
}

export const MissionList = ({ missions }: MissionListProps) => {
  return (
    <div className="relative rounded-xl p-px bg-gradient-to-b from-green-500/40 to-slate-800 shadow-2xl shadow-green-500/10 transition-all duration-300 hover:shadow-green-500/20">
      <div className="bg-slate-900/80 backdrop-blur-sm rounded-[11px] p-6">
        <h3 className="text-2xl font-bold text-green-300 flex items-center mb-4 drop-shadow-[0_0_5px_theme(colors.green.500)]">
          <SatelliteIcon />
          Active & Recent Missions
        </h3>
        <ul className="space-y-4">
          {missions.map((mission, index) => (
            <li key={index} className="border-l-4 border-green-400/60 pl-4 transition-all duration-300 hover:border-green-300 hover:bg-white/5 rounded-r-md py-1">
              <h4 className="font-semibold text-lg text-gray-100">{mission.name}</h4>
              <p className="text-gray-400 whitespace-pre-wrap">{mission.description.trim()}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
