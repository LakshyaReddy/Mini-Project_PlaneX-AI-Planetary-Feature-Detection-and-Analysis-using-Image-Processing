import React, { useState, useCallback } from 'react';
import { UploadIcon } from './icons';

interface ImageUploaderProps {
  onImageUpload: (base64: string, file: File) => void;
}

export const ImageUploader = ({ onImageUpload }: ImageUploaderProps) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = useCallback((file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = (e.target?.result as string).split(',')[1];
        if (base64) {
          onImageUpload(base64, file);
        }
      };
      reader.readAsDataURL(file);
    }
  }, [onImageUpload]);

  const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const uploaderClass = `relative block w-full max-w-lg rounded-xl p-1 text-center transition-all duration-300 group ${isDragging ? 'scale-105' : ''}`;

  return (
    <div className="flex justify-center items-center">
      <div 
        onDragOver={onDragOver} 
        onDragLeave={onDragLeave} 
        onDrop={onDrop} 
        className={uploaderClass}
      >
        <div className={`absolute inset-0 bg-gradient-to-br from-purple-600 to-cyan-400 rounded-xl transition-all duration-300 ${isDragging ? 'opacity-100' : 'opacity-50 group-hover:opacity-75'}`}></div>
        <div className="relative bg-black/50 backdrop-blur-sm rounded-lg p-10 border border-gray-800/80">
            <div className="flex flex-col items-center justify-center space-y-3">
                <div className="p-3 bg-gray-900/50 rounded-full">
                    <UploadIcon />
                </div>
                <span className="mt-2 block font-medium text-gray-200">
                Drag & Drop Planetary Image
                </span>
                <span className="text-xs text-gray-500">or</span>
                <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-cyan-400 hover:text-cyan-300 focus-within:outline-none">
                <span> browse files</span>
                <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={onFileChange} accept="image/*" />
                </label>
            </div>
        </div>
      </div>
    </div>
  );
};
