import React from 'react';
import { PlanetIcon } from './icons';

interface PlanetInfoCardProps {
  name: string;
  info: string;
}

export const PlanetInfoCard = ({ name, info }: PlanetInfoCardProps) => {
  return (
    <div className="relative rounded-xl p-px bg-gradient-to-b from-cyan-400/40 to-slate-800 shadow-2xl shadow-cyan-500/10 transition-all duration-300 hover:shadow-cyan-500/20">
      <div className="bg-slate-900/80 backdrop-blur-sm rounded-[11px] p-6">
        <h2 className="text-3xl font-bold text-cyan-300 flex items-center mb-3 drop-shadow-[0_0_5px_theme(colors.cyan.500)]">
          <PlanetIcon />
          {name}
        </h2>
        <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">
          {info.trim()}
        </p>
      </div>
    </div>
  );
};
